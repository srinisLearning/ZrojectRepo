import React from "react";
import BidsPlacedByUser from "../bids-placed/page";

function BidsWon() {
  return (
    <div>
      <BidsPlacedByUser status="won" />
    </div>
  );
}

export default BidsWon;
